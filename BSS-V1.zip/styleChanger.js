function setStyle(colorbg, colorte, colortb, colortt) {
    // Edit source from Smarter Smartschool!
    let style = document.createElement('style');
    style.innerHTML = `

    body, input, select, textarea,
    h1, h2, h3, h4, h5, h6, td,
    .smsc-title--1, .course__block, .news__feed__button__content, .topnav__menu, .topnav__menuitem,
    .toolbar, .folders, .helper--height--mega, .modern-message,
    .smscMainBlockContainer, .nodata_msg, .eval_content, .course,
    .smscToolbar, .smscleftnavcontainer, .smsc-column-nav__button, .notification__btn, #smscMainBlockContainer, .smscAdminNav_body_linkdivText, .smscAdminNav_body_linkdivTitle, .smsc-container, .smsc-tree__item__title, #smscFrameTitlePanel,
    .postbox_link, .toaster__toast, .full_pie_icon, .eval_title, .eval_comment, .notifs-toaster__toast, .notification,
    #smscMain, .smscComposeMessage, #msg_bg, .msg_button,
    .tabmain, .templateselectdiv, .templateName, .templateRow,
    .login-app__linkbutton, .login-app__infoblock--margin-bottom, .login-app__infoblock--title, .login-app__infoblock,
    .searchDivResult, #modal-content, .side-panel__panel,
    .color_snow_white, .agenda_grid_main, .contentContainer, .agenda_grid_header_day, #rightContainerTotal, #agenda_main, .rightContainer, tasksandmaterials-panel, .tasksAndMaterials__container, #rightContainerBottom, #contentContainerBottom, .menuContainer, .navigationContainer, .border {
        color: ` + colorte + ` !important;
        background-color: ` + colorbg + ` !important;
    }

    span {
      color: ` + colorte + ` !important;
    }

    #msgdetail, #agenda_main, .eval_grid_graph, #uploadzone, #tree, #resizeHandle, #mod_content_center, .searchInputField, #subjectInput, #navNext, #navPrev, .calendarMainTable, .smsc_cm_body_row_block, .smsc_cm_body_row_block_indien, .searchInputField, .menuContainerTotal, #border {
        color: #000000 !important;
        background-color: #ffffff !important;
    }

    .compose_title, .usersContainerBlockText {
        color: #000000 !important;
    }

    .topnav, .topnav__btn, .topnav__title, .blob-group__blob, .wide-toolbar, .wide-toolbar__item, .cell {
        color: ` + colortt + ` !important;
        background-color: ` + colortb + ` !important;
    }

    .smsc-topnav .topnav__menu-arrow:after {
        border-color: ` + colorbg + ` transparent !important;
    }
    `;
    document.head.appendChild(style);
}

chrome.storage.sync.get({
    theme: 'light',
    colorbg: '#FFFFFF',
    colorte: '#262626',
    colortb: '#FF520E',
    colortt: '#FFFFFF',
}, function (items) {
    if (items.theme == 'off') {
        return;
    }
    if (items.theme == 'light') {
        setStyle('#ffffff', '#262626', '#f77d36', '#ffffff');
    }
    if (items.theme == 'dark') {
        setStyle('#161717', '#ffffff', '#1e1e1f', '#ffffff');
    }
    if (items.theme == 'amoled') {
        setStyle('#0a0a0a', '#ffffff', '#0a0a0a', '#ffffff');
    }
    if (items.theme == 'red') {
        setStyle('#82170d', '#ffffff', '#420a05', '#ffffff');
    }
    if (items.theme == 'blue') {
        setStyle('#3c68c7', '#ffffff', '#08114d', '#ffffff');
    }
    if (items.theme == 'green') {
        setStyle('#88ad57', '#18181a', '#3a6637', '#ffffff');
    }
    if (items.theme == 'space') {
        setStyle('#08010d', '#ffffff', '#3a0b40', '#ffffff');
    }
});
