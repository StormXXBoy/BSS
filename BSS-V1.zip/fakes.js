window.addEventListener("DOMContentLoaded", (event) => {
  let msgMessage = document.querySelector(".js-badge-msg");
  chrome.storage.sync.get('fmessages', function (f) {
      if (f.fmessages == '0' || f.fmessages == 'undefined' || f.fmessages == 'nil' || f.fmessages == '') {
        return;
      } else {
        msgMessage.removeAttribute("hidden");
        msgMessage.innerHTML = (f.fmessages);
      }
  });
  let msgAnnounce = document.querySelector(".js-badge-notifs");
  chrome.storage.sync.get('fannouncments', function (f) {
      if (f.fannouncments == '0' || f.fannouncments == 'undefined' || f.fannouncments == 'nil' || f.fannouncments == '') {
        return;
      } else {
        msgAnnounce.removeAttribute("hidden");
        msgAnnounce.innerHTML = (f.fannouncments);
      }
  });
  let profile = document.querySelector(".js-btn-profile");
  let profileNameHolder = profile.querySelector(".hlp-vert-box");
  let profileSpans = profileNameHolder.querySelectorAll("span");
  let profileName = profileSpans[0];
  let profileSeccond = profileSpans[1];
  chrome.storage.sync.get('cname', function (f) {
      if (f.cname.toUpperCase() == 'NAAM' || f.fannouncments == 'undefined') {
        return;
      } else {
        profileSeccond.innerHTML = profileName.innerHTML;
        profileName.innerHTML = (f.cname);
      }
  });
});
