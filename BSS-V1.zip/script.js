function Cmain_nav(href, title) {
  const Nhref = document.createElement('a');
  var nWrapper = document.getElementById('smscTopContainer');
  var nav = nWrapper.querySelector('nav');

  Nhref.className = 'topnav__btn topnav__btn--push-right';
  Nhref.href = href;
  Nhref.style.margin = '0px';
  Nhref.innerHTML = title;

  nav.appendChild(Nhref);
}

function Cinfo() {
  const Nhref = document.createElement('a');
  var sWrapper = document.getElementById('shortcutsMenu');
  var shortcuts = sWrapper.querySelector('div');
  const guideC = shortcuts.childNodes[24];

  Nhref.className = 'topnav__menuitem topnav__menuitem--icon module-manual--24';
  Nhref.href = 'https://stormxxboy.com/projects/bss';
  Nhref.innerHTML = 'Better Smartschool';
  Nhref.setAttribute('style', 'margin-right: 1.333rem;');
  Nhref.setAttribute('column-index', '1');
  Nhref.setAttribute('item-index', '0');
  Nhref.setAttribute('role', 'menuitem');

  shortcuts.insertBefore(Nhref, guideC);
}

function Cshortcut(href, title, col, item) {
  const Nhref = document.createElement('a');
  var sWrapper = document.getElementById('shortcutsMenu');
  var shortcuts = sWrapper.querySelector('div');
  const guideC = shortcuts.childNodes[22];

  Nhref.className = 'topnav__menuitem topnav__menuitem--icon module-manual--24';
  Nhref.href = href;
  Nhref.innerHTML = title;
  Nhref.setAttribute('style', 'margin-right: 1.333rem;');
  Nhref.setAttribute('column-index', col);
  Nhref.setAttribute('item-index', item);
  Nhref.setAttribute('role', 'menuitem');

  shortcuts.insertBefore(Nhref, guideC);
  var Qhr = sWrapper.querySelector('hr');
  Qhr.remove();
}

Cmain_nav('/index.php?module=Agenda', 'Schoolagenda');
Cmain_nav('/results/main/results/details', 'Resultaten');
Cinfo();
Cshortcut('/index.php?module=Manual&file=manual&layout=2&id=handleiding:zoeken', 'Zoekfunctie', '0', '0');
