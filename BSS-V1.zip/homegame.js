window.addEventListener("DOMContentLoaded", (event) => {
  let center = document.getElementById("centercontainer");
  let mains = center.querySelectorAll(".homepage__block__content");
  let main = mains[0];
  let texts = center.querySelectorAll(".homepage__block__top");
  let text = texts[0];
  chrome.storage.sync.get('hgame', function (f) {
      if (f.hgame == 'off' || f.hgame == 'undefined') {
        return;
      } else {
        text.remove();
        main.innerHTML = '';
        let game = document.createElement('iframe');
        game.style.size = '100%';
        main.appendChild(game);
        if (f.hgame == 'dino') {
          game.src = 'https://www.greenfoot.org/scenarios/23252?embed=true';
        } else if (f.hgame == 'checkers') {
          game.src = 'https://playpager.com/embed/checkers/index.html';
          game.setAttribute('scrolling', 'no');
        } else if (f.hgame == 'chess') {
          game.src = 'https://playpager.com/embed/chess/index.html';
          game.setAttribute('scrolling', 'no');
        }
      }
  });
});
