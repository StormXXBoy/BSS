function save_options() {
    let theme = $('#theme').val();
    chrome.storage.sync.set({
        theme: theme,
    }, function () {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.update(tabs[0].id, { url: tabs[0].url });
        });
    });
}

function save_fakes() {
    let fmessages = $('#fmessages').val();
    let fannouncments = $('#fannouncments').val();
    let cname = $('#cname').val();
    chrome.storage.sync.set({
        fmessages: fmessages,
        fannouncments: fannouncments,
        cname: cname,
    }, function () {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.update(tabs[0].id, { url: tabs[0].url });
        });
    });
}

function save_game() {
    let hgame = $('#homegame').val();
    chrome.storage.sync.set({
        hgame: hgame,
    }, function () {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.update(tabs[0].id, { url: tabs[0].url });
        });
    });
}

function restore_options() {
    chrome.storage.sync.get({
        theme: 'off',
    }, function (items) {
            $('#theme').val(items.theme);
    });
}

function restore_fakes() {
    chrome.storage.sync.get({
      fmessages: '0',
      fannouncments: '0',
      cname: 'Naam',
    }, function (items) {
            $('#fmessages').val(items.fmessages);
            $('#fannouncments').val(items.fannouncments);
            $('#cname').val(items.cname);
    });
}

function restore_game() {
    chrome.storage.sync.get({
        hgame: 'off',
    }, function (items) {
            $('#homegame').val(items.hgame);
    });
}

$(function () {
    $('#save').click(save_options);
      restore_options();
    $('#save1').click(save_fakes);
      restore_fakes();
    $('#save2').click(save_game);
      restore_game();
});
