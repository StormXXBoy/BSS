function addScoreDisp(type) {
  const scores = document.querySelectorAll("."+type);
  const title = document.querySelector(".js-title-and-schoolyear-selector");

  const scoresH = document.createElement('h1');
  scoresH.className = type;
  scoresH.setAttribute('style', 'border-radius: 100%; width: 55px; height: 55px; margin: 2.5px; text-align: center;');
  scoresH.innerHTML = scores.length;
  title.appendChild(scoresH);
}

window.addEventListener("DOMContentLoaded", (event) => {
  setTimeout(function() {
    addScoreDisp("c-steel-combo--100");
    addScoreDisp("c-black-combo--100");
    addScoreDisp("c-red-combo--100");
    addScoreDisp("c-yellow-combo--100");
    addScoreDisp("c-olive-combo--100");
    addScoreDisp("c-green-combo--100");
  }, 2500);
});
